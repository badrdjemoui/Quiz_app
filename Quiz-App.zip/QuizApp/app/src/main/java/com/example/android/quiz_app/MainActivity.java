package com.example.android.quiz_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

/***************************************global variable***********************************/
    int CorrectAnswer = 0;
    int noselected =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

/****************************************************************************************************/
    public void strIsTrue(String str, int selectedradio) {


        if (selectedradio != -1)  // no radio button selected
       {
            RadioButton selectedRadioButton = (RadioButton) findViewById(selectedradio);
            String answer = selectedRadioButton.getText().toString();
            if (answer.equals(str)) {
                CorrectAnswer++;
            }
        }
        else{ noselected++;}

    }
/*****************************************************************************************************/
    public void correction(View view) {
/********************************top of ScrollView***********************/
        ScrollView sv = (ScrollView)findViewById(R.id.TopView);
        sv.scrollTo(0, sv.getTop());

        /***********************corrects Answers**********************/
        RadioButton rb1,rb2,rb3,rb4,rb5,rb6,rb7,rb8;
        rb1=findViewById(R.id.Ans_q1_C);rb1.setTextColor(Color.GREEN);
        rb2=findViewById(R.id.Ans_q2_D);rb2.setTextColor(Color.GREEN);
        rb3=findViewById(R.id.Ans_q3_C);rb3.setTextColor(Color.GREEN);
        rb4=findViewById(R.id.Ans_q4_A);rb4.setTextColor(Color.GREEN);
        rb5=findViewById(R.id.Ans_q5_D);rb5.setTextColor(Color.GREEN);
        rb6=findViewById(R.id.Ans_q6_D);rb6.setTextColor(Color.GREEN);
        rb7=findViewById(R.id.Ans_q7_C);rb7.setTextColor(Color.GREEN);
        rb8=findViewById(R.id.Ans_q8_B);rb8.setTextColor(Color.GREEN);


                          /*******question 1********/

        RadioGroup radioGroup1 = (RadioGroup) findViewById(R.id.quest1);
        int selectedradio1 = radioGroup1.getCheckedRadioButtonId();
        strIsTrue(getString(R.string.A1_3), selectedradio1);

       // RadioButton selected1 = (RadioButton) findViewById(selectedradio1);
       // selected1.setTextColor(Color.GREEN);
                          /*******question 2********/

        RadioGroup radioGroup2 = (RadioGroup) findViewById(R.id.quest2);
        int selectedradio2 = radioGroup2.getCheckedRadioButtonId();
        strIsTrue(getString(R.string.A2_4), selectedradio2);

                          /*******question 3********/
        RadioGroup radioGroup3 = (RadioGroup) findViewById(R.id.quest3);
        int selectedradio3 = radioGroup3.getCheckedRadioButtonId();
        strIsTrue(getString(R.string.A3_3), selectedradio3);

                          /*******question 4********/
        RadioGroup radioGroup4 = (RadioGroup) findViewById(R.id.quest4);
        int selectedradio4 = radioGroup4.getCheckedRadioButtonId();
        strIsTrue(getString(R.string.A4_1), selectedradio4);

                          /*******question 5********/
        RadioGroup radioGroup5 = (RadioGroup) findViewById(R.id.quest5);
        int selectedradio5 = radioGroup5.getCheckedRadioButtonId();
        strIsTrue(getString(R.string.A5_4), selectedradio5);

                           /*******question 6********/
        RadioGroup radioGroup6 = (RadioGroup) findViewById(R.id.quest6);
        int selectedradio6 = radioGroup6.getCheckedRadioButtonId();
        strIsTrue(getString(R.string.A6_2), selectedradio6);

                           /*******question 7********/
        RadioGroup radioGroup7 = (RadioGroup) findViewById(R.id.quest7);
        int selectedradio7 = radioGroup7.getCheckedRadioButtonId();
        strIsTrue(getString(R.string.A7_3), selectedradio7);

                            /*******question 8********/
        RadioGroup radioGroup8 = (RadioGroup) findViewById(R.id.quest8);
        int selectedradio8 = radioGroup8.getCheckedRadioButtonId();
        strIsTrue(getString(R.string.A8_2), selectedradio8);
                         /**************************************/

        String message1 = "you have " + String.valueOf(noselected) + " question not respensed yet";
        Toast.makeText(MainActivity.this, message1, Toast.LENGTH_LONG).show();

        String message = "you have  " + String.valueOf(CorrectAnswer) + "/8 correct answers";
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
    }
/*********************************************************************************************************/
    public void initialise(View view) {
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }
/*******************************************************************************************************/
    public void close(View view) {
        this.finish();
    }
 /***************************************************/
}
